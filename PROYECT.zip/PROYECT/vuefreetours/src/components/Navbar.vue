<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <!-- logo -->
      <router-link to="/" class="navbar-brand d-flex align-items-center">
        <img :src="logo" alt="Logo" class="logo">
        <span class="ms-2 fw-bold text-white">DreamTours</span>
      </router-link>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li v-if="!usuario" class="nav-item">
            <router-link to="/login" class="btn btn-light fw-bold px-4">Iniciar Sesión</router-link>
          </li>

          <template v-else>
            <li class="nav-item">
              <span class="nav-link fw-bold text-white">👤 {{ usuario.nombre }} ({{ usuario.rol }})</span>
            </li>

            <!-- cliente -->
            <li v-if="usuario.rol === 'cliente'" class="nav-item">
              <router-link to="/mis-rutas" class="nav-link text-white">Mis Rutas</router-link>
              <router-link to="/mis-reservas" class="nav-link text-white">Mis Reservas</router-link>
            </li>

            <!-- guia -->
            <li v-if="usuario.rol === 'guia'" class="nav-item">
              <router-link to="/guia/rutas" class="nav-link text-white">Mis Rutas Asignadas</router-link>
            </li>

            <!-- admin -->
            <li v-if="usuario.rol === 'admin'" class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-warning fw-bold" href="#" role="button" data-bs-toggle="dropdown">
                Panel Admin
              </a>
              <ul class="dropdown-menu">
                <li><router-link to="/" class="dropdown-item">Inicio Admin</router-link></li>
                <li><router-link to="/admin/usuarios" class="dropdown-item">Gestionar Usuarios</router-link></li>
                <li><router-link to="/admin/rutas" class="dropdown-item">Gestionar Rutas</router-link></li>
              </ul>
            </li>

            <li class="nav-item">
              <button @click="cerrarSesion" class="btn btn-danger ms-2">Cerrar Sesión</button>
            </li>
          </template>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';

const usuario = ref(JSON.parse(localStorage.getItem('usuario')) || null);
const router = useRouter();

const actualizarUsuario = () => {
  usuario.value = JSON.parse(localStorage.getItem('usuario'));
};

onMounted(() => {
  window.addEventListener('storage', actualizarUsuario);
});
onUnmounted(() => {
  window.removeEventListener('storage', actualizarUsuario);
});

const cerrarSesion = () => {
  localStorage.removeItem('usuario');
  window.dispatchEvent(new Event('storage'));
  router.push('/');
};

import logo from '@/assets/logo.png';
</script>

<style scoped>
.logo {
  height: 45px;
}

.navbar {
  transition: all 0.3s ease-in-out;
}

.navbar .nav-link {
  font-size: 1.1rem;
  transition: color 0.3s;
}

.navbar .nav-link:hover {
  color: #ffd700 !important;
}

.dropdown-menu {
  min-width: 200px;
}

.btn-light {
  border-radius: 30px;
}

.btn-danger {
  border-radius: 20px;
}
</style>
