<template>
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <h2 class="text-center">Iniciar Sesión</h2>
          <div v-if="error" class="alert alert-danger">{{ error }}</div>
          <form @submit.prevent="login">
            <div class="mb-3">
              <label class="form-label">Correo Electrónico</label>
              <input v-model="email" type="email" class="form-control" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Contraseña</label>
              <input v-model="password" type="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Ingresar</button>
          </form>
          <p class="mt-3 text-center">
            ¿No tienes cuenta? <router-link to="/register">Regístrate aquí</router-link>
          </p>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { useRouter } from 'vue-router';
  
  const email = ref('');
  const password = ref('');
  const error = ref(null);
  const router = useRouter();
  
  const login = async () => {
    error.value = null;
    try {
      const response = await fetch('http://localhost/freetours/api.php/usuarios?login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.value, contraseña: password.value })
      });
  
      const data = await response.json();
      
      if (data.status === 'success') {
        localStorage.setItem('usuario', JSON.stringify(data.user));
        window.dispatchEvent(new Event('storage')); // dispatch actualiza el Navbar
        router.push('/');
      } else {
        error.value = data.message;
      }
    } catch (err) {
      error.value = 'Error en el servidor.';
    }
  };
  </script>
  
  