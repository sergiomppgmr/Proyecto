<template>
    <div class="container mt-4">
      <h2 class="text-center mb-4">Panel de Administración</h2>
  
      <div class="row">
        <div class="col-md-6">
          <router-link to="/admin/usuarios" class="btn btn-primary w-100 mb-3">Gestionar Usuarios</router-link>
        </div>
        <div class="col-md-6">
          <router-link to="/admin/rutas" class="btn btn-secondary w-100">Gestionar Rutas</router-link>
        </div>
      </div>
    </div>
  </template>
  