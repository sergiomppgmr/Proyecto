<template>
    <div class="container mt-4">
        <h2 class="text-center mb-4">⭐ Mis Rutas Realizadas</h2>
  
        <div v-if="rutas.length > 0" class="row">
            <div v-for="ruta in rutas" :key="ruta.reserva_id" class="col-md-6">
                <div class="card ruta-card">
                    <img :src="obtenerRutaImagen(ruta.ruta_foto)" class="card-img-top" alt="Ruta">
                    <div class="card-body text-center">
                        <h5 class="card-title">{{ ruta.ruta_titulo }}</h5>
                        <p class="card-text"><strong>📍 Localidad:</strong> {{ ruta.ruta_localidad }}</p>
                        <p class="card-text"><strong>📅 Fecha:</strong> {{ ruta.ruta_fecha }}</p>
                        <p class="card-text"><strong>📖 Descripción:</strong> {{ ruta.ruta_descripcion }}</p>
  
                        <!-- Valoracion -->
                        <div v-if="!ruta.yaValorada" class="rating-section">
                            <h6>Valorar esta ruta:</h6>
                            <div class="rating">
                                <span v-for="star in 5" :key="star" @click="valorarRuta(ruta, star)" 
                                      :class="{ 'selected': star <= ruta.valoracion }">⭐</span>
                            </div>
                            <textarea v-model="ruta.comentario" class="form-control mt-2" placeholder="Escribe un comentario"></textarea>
                            <button @click="enviarValoracion(ruta)" class="btn btn-success mt-2 w-100">Enviar Valoración</button>
                        </div>
  
                        <div v-else>
                            <p><strong>⭐ Valoración:</strong> {{ ruta.valoracion }} estrellas</p>
                            <p><strong>📝 Comentario:</strong> {{ ruta.comentario || "Sin comentario" }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  
        <div v-else class="alert alert-info text-center">
            No has realizado ninguna ruta aún.
        </div>
    </div>
  </template>

<script setup>
import { ref, onMounted } from 'vue';

const rutas = ref([]);
const usuario = ref(JSON.parse(localStorage.getItem('usuario')) || null);

// Cargar rutas realizadas usuario
const cargarRutasRealizadas = async () => {
  if (!usuario.value || !usuario.value.email) return;

  try {
      const response = await fetch(`http://localhost/freetours/api.php/reservas?email=${usuario.value.email}`);

      if (!response.ok) {
          throw new Error("Error en la API: " + response.statusText);
      }

      const data = await response.json();
      console.log("🔍 Rutas realizadas:", data);

      rutas.value = data.map(ruta => ({
          ...ruta,
          yaValorada: ruta.valoracion !== null,
          valoracion: ruta.valoracion || 0,
          comentario: ruta.comentario || ""
      }));

      console.log("✅ Rutas final asignadas:", rutas.value);

  } catch (error) {
      console.error("❌ Error al obtener rutas realizadas:", error);
  }
};

// Cargar comentarios desde la API 
const cargarComentarios = async () => {
  try {
      const response = await fetch('http://localhost/freetours/api.php/valoraciones');

      if (!response.ok) {
          throw new Error("Error en la API de valoraciones: " + response.statusText);
      }

      const valoraciones = await response.json();
      console.log("📝 Valoraciones obtenidas:", valoraciones);

      rutas.value.forEach(ruta => {
          const valoracion = valoraciones.find(v => v.ruta_id === ruta.ruta_id && v.cliente_id === usuario.value.id);
          if (valoracion) {
              ruta.comentario = valoracion.comentario;
          }
      });

      console.log("✅ Rutas con comentarios actualizados:", rutas.value);

  } catch (error) {
      console.error("❌ Error al obtener valoraciones:", error);
  }
};

// Guardar la valoracion en la API
const enviarValoracion = async (ruta) => {
  if (!usuario.value || !usuario.value.id) {
      alert("Error: No se encontró el usuario logueado.");
      return;
  }

  if (!ruta.valoracion || ruta.valoracion < 1 || ruta.valoracion > 5) {
      alert("Por favor, selecciona una valoración entre 1 y 5 estrellas.");
      return;
  }

  try {
      console.log(" Enviando valoración:", {
          user_id: usuario.value.id,
          ruta_id: ruta.ruta_id,
          estrellas: ruta.valoracion,
          comentario: ruta.comentario || ""
      });

      const response = await fetch('http://localhost/freetours/api.php/valoraciones', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
              user_id: usuario.value.id,
              ruta_id: ruta.ruta_id,
              estrellas: ruta.valoracion,
              comentario: ruta.comentario || ""
          })
      });

      const data = await response.json();
      console.log(" Respuesta API Valoraciones:", data);

      if (data.status === "success") {
          alert("Valoración enviada con éxito.");
          ruta.yaValorada = true;
      } else {
          alert("Error al enviar la valoración: " + data.message);
      }
  } catch (error) {
      console.error("Error al enviar la valoración:", error);
  }
};

// funcion puntuacion estrellas
const valorarRuta = (ruta, puntuacion) => {
  ruta.valoracion = puntuacion;
  console.log(`⭐ Ruta ${ruta.ruta_id} valorada con: ${puntuacion} estrellas`);
};

// img ruta
const obtenerRutaImagen = (nombreImagen) => {
  return nombreImagen ? `http://localhost/freetours/imagenes/${nombreImagen}` : "/default-image.jpg";
};

// Cargar las rutas y comentarios
onMounted(async () => {
  await cargarRutasRealizadas();
  await cargarComentarios();
});
</script>

<style scoped>
.ruta-card {
  transition: transform 0.3s, box-shadow 0.3s;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.ruta-card:hover {
  transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.rating span {
  font-size: 24px;
  cursor: pointer;
}

.rating .selected {
  color: gold;
}

.rating-section {
  border-top: 1px solid #ccc;
  padding-top: 10px;
}
</style>
