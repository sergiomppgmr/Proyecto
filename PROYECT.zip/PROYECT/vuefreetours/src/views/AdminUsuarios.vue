<template>
  <div class="container mt-4">
    <h2 class="text-center mb-4">👤 Gestión de Usuarios</h2>

    <div v-if="usuarios.length > 0" class="table-responsive">
      <table class="table table-hover">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="usuario in usuarios" :key="usuario.id">
            <td>{{ usuario.id }}</td>
            <td>{{ usuario.nombre }}</td>
            <td>{{ usuario.email }}</td>
            <td>
              <select v-model="usuario.rol" @change="cambiarRol(usuario)" class="form-select">
                <option value="cliente">Cliente</option>
                <option value="guia">Guía</option>
                <option value="admin">Administrador</option>
              </select>
            </td>
            <td>
              <button @click="eliminarUsuario(usuario.id)" class="btn btn-outline-danger btn-sm">
                ❌ Eliminar
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-else class="alert alert-warning text-center">
      No hay usuarios registrados.
    </div>
  </div>
</template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  
  const usuarios = ref([]);
  
  //  Cargar usuarios desde la API
  const cargarUsuarios = async () => {
    try {
      const response = await fetch('http://localhost/freetours/api.php/usuarios');
      const data = await response.json();
      usuarios.value = data;
      console.log("Usuarios cargados:", usuarios.value);
    } catch (error) {
      console.error("Error al obtener usuarios:", error);
    }
  };
  
  //  Cambiar rol usuario
  const cambiarRol = async (usuario) => {
    try {
      const response = await fetch(`http://localhost/freetours/api.php/usuarios?id=${usuario.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rol: usuario.rol })
      });
  
      const data = await response.json();
      if (data.status === 'success') {
        alert("Rol actualizado correctamente.");
      } else {
        alert("Error al actualizar rol.");
      }
    } catch (error) {
      console.error("Error al cambiar el rol:", error);
    }
  };
  
  //  Eliminar usuario
  const eliminarUsuario = async (usuarioId) => {
    if (!confirm("¿Seguro que deseas eliminar este usuario?")) return;
  
    try {
      const response = await fetch(`http://localhost/freetours/api.php/usuarios?id=${usuarioId}`, {
        method: 'DELETE'
      });
  
      const data = await response.json();
      if (data.status === 'success') {
        alert("Usuario eliminado.");
        usuarios.value = usuarios.value.filter(user => user.id !== usuarioId);
      } else {
        alert("Error al eliminar usuario.");
      }
    } catch (error) {
      console.error("Error al eliminar usuario:", error);
    }
  };

  //  Cargar usuarios
  onMounted(() => {
    cargarUsuarios();
  });
  </script>
  
  <style scoped>
.table-hover tbody tr:hover {
  background-color: #f8f9fa;
}

.btn-outline-danger {
  transition: all 0.3s;
}

.btn-outline-danger:hover {
  background-color: red;
  color: white;
}
</style>