<template>
  <div class="container mt-5">
    <div v-if="ruta" class="row">
      <!-- imagen de la ruta -->
      <div class="col-md-6">
        <div class="image-container">
          <img 
            :src="obtenerRutaImagen(ruta.foto)" 
            class="img-fluid rounded shadow-lg" 
            alt="Ruta"
            @error="imagenNoDisponible"
          >
        </div>
      </div>

      <!-- informacion de la ruta -->
      <div class="col-md-6">
        <h2 class="text-primary">{{ ruta.titulo }}</h2>
        <p><strong>📍 Localidad:</strong> {{ ruta.localidad || 'No disponible' }}</p>
        <p><strong>📅 Fecha:</strong> {{ ruta.fecha || 'No disponible' }}</p>
        <p><strong>⏰ Hora:</strong> {{ ruta.hora || 'No disponible' }}</p>
        <p><strong>📝 Descripción:</strong> {{ ruta.descripcion || 'No disponible' }}</p>

        <!-- punto de encuentro -->
        <div v-if="ruta.latitud && ruta.longitud" class="mt-4">
          <h4 class="text-success">📍 Punto de Encuentro:</h4>
          <div id="map" class="rounded shadow-lg"></div>
        </div>

        <!-- seleccionar num de personas -->
        <div v-if="usuario && usuario.rol === 'cliente'" class="mt-4">
          <label for="numPersonas"><strong>👥 Número de Personas:</strong></label>
          <input 
            id="numPersonas" 
            type="number" 
            v-model="numeroPersonas" 
            min="1" max="8" 
            class="form-control w-50"
          >
        </div>

        <!-- btn reservar -->
        <button 
          v-if="usuario && usuario.rol === 'cliente'" 
          @click="reservarRuta" 
          class="btn btn-primary mt-4 w-100 rounded-pill shadow">
          🚀 Reservar Ruta
        </button>
      </div>
    </div>

    <!-- Mensaje de carga -->
    <div v-else class="text-center">
      <div class="spinner-border text-primary" role="status"></div>
      <p class="mt-2">Cargando detalles de la ruta...</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue';
import { useRoute } from 'vue-router';
import L from 'leaflet';

// Variables reactivas
const numeroPersonas = ref(1);
const ruta = ref(null);
const usuario = ref(JSON.parse(localStorage.getItem('usuario')) || null);
const route = useRoute();
let map = null;

// cargar detalles de la ruta desde la API
const cargarRuta = async () => {
  try {
    const rutaId = route.params.id;
    if (!rutaId) return;

    const response = await fetch(`http://localhost/freetours/api.php/rutas/${rutaId}`);
    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      ruta.value = data.find(r => r.id == rutaId) || null;
      await nextTick();
      inicializarMapa();
    } else {
      ruta.value = null;
    }
  } catch (error) {
    console.error("Error al cargar la ruta:", error);
  }
};

// Inicializar el mapa con Leaflet
const inicializarMapa = () => {
  if (!ruta.value?.latitud || !ruta.value?.longitud) return;

  if (map) map.remove();

  map = L.map('map').setView([ruta.value.latitud, ruta.value.longitud], 15);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  L.marker([ruta.value.latitud, ruta.value.longitud])
    .addTo(map)
    .bindPopup(`<strong>${ruta.value.titulo}</strong><br>Punto de encuentro.`)
    .openPopup();
};

// reservar ruta
const reservarRuta = async () => {
  if (!usuario.value?.email) {
    alert("Debes iniciar sesión para reservar.");
    return;
  }

  try {
    const response = await fetch('http://localhost/freetours/api.php/reservas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: usuario.value.email,  
        ruta_id: ruta.value.id,
        num_personas: numeroPersonas.value
      })
    });

    const data = await response.json();
    if (data.status === "success") {
      alert("Reserva realizada correctamente");
    } else {
      alert("Error en la reserva.");
    }
  } catch (error) {
    console.error("Error al reservar la ruta:", error);
  }
};

// obtener imagen
const obtenerRutaImagen = (nombreImagen) => nombreImagen ? `http://localhost/freetours/imagenes/${nombreImagen}` : "/default-image.jpg";
const imagenNoDisponible = (event) => event.target.src = "/default-image.jpg";

onMounted(() => cargarRuta());
</script>

<style scoped>
.image-container {
  display: flex;
  justify-content: center;
}

#map {
  height: 300px;
  width: 100%;
  border-radius: 10px;
  margin-top: 15px;
}

.btn-primary {
  font-size: 1.2rem;
  font-weight: bold;
  transition: all 0.3s;
}

.btn-primary:hover {
  background-color: #0056b3;
  transform: scale(1.05);
}
</style>
