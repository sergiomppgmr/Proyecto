<template>
    <div class="container mt-4">
      <h2 class="text-center mb-4 text-success">📌 Mis Rutas Asignadas</h2>
  
      <div v-if="rutas.length > 0" class="row">
        <div v-for="ruta in rutas" :key="ruta.id" class="col-md-6">
          <div class="card ruta-card">
            <img :src="obtenerRutaImagen(ruta.foto)" class="card-img-top" alt="Ruta">
            <div class="card-body text-center">
              <h5 class="card-title">{{ ruta.titulo }}</h5>
              <p><strong>📍 Localidad:</strong> {{ ruta.localidad }}</p>
              <p><strong>📅 Fecha:</strong> {{ ruta.fecha }}</p>
              <p><strong>⏰ Hora:</strong> {{ ruta.hora }}</p>
            </div>
          </div>
        </div>
      </div>
  
      <div v-else class="alert alert-warning text-center">
        No tienes rutas asignadas.
      </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const usuario = ref(JSON.parse(localStorage.getItem('usuario')) || null);
const rutas = ref([]);

const cargarRutasGuia = async () => {
  if (!usuario.value || usuario.value.rol !== 'guia') return;

  try {
    //  asignaciones 
    const responseAsignaciones = await fetch(`http://localhost/freetours/api.php/asignaciones?guia_id=${usuario.value.id}`);
    const asignaciones = await responseAsignaciones.json();

    const rutasIds = asignaciones.map(asignacion => asignacion.ruta_id);

    const rutasCompletas = await Promise.all(
      rutasIds.map(async (id) => {
        const responseRuta = await fetch(`http://localhost/freetours/api.php/rutas?id=${id}`);
        return await responseRuta.json();
      })
    );

    rutas.value = rutasCompletas.flat();
  } catch (error) {
    console.error("Error al obtener rutas del guía:", error);
  }
};

onMounted(() => {
  cargarRutasGuia();
});


const obtenerRutaImagen = (nombreImagen) => {
  return nombreImagen ? `http://localhost/freetours/imagenes/${nombreImagen}` : "/default-image.jpg";
};
</script>

<style scoped>
.ruta-card {
  border-radius: 15px;
  transition: transform 0.3s;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.ruta-card:hover {
  transform: scale(1.05);
}
</style>
