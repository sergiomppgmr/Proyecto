<template>
  <div class="home-container">
    <!-- video -->
    <div class="video-section" @click="toggleVideo">
      <video ref="videoRef" class="video" autoplay loop muted>
        <source src="@/assets/video.mp4" type="video/mp4">
        Tu navegador no soporta videos.
      </video>
      <div class="overlay"></div>
    </div>

    <!-- buscador -->
    <div class="container mt-5">
      <div class="jumbotron text-center p-5">
        <h1 class="display-4 text-white">Descubre el mundo con <span class="text-warning">DreamTours</span></h1>
        <p class="lead text-white">Encuentra los mejores Free Tours y vive experiencias inolvidables.</p>
      </div>

      <div class="row justify-content-center mt-4">
        <div class="col-md-5">
          <input v-model="filtroLocalidad" type="text" class="form-control search-input" placeholder="🔍 Buscar por localidad">
        </div>
        <div class="col-md-5">
          <input v-model="filtroFecha" type="date" class="form-control search-input">
        </div>
        <div class="col-md-2">
          <button @click="filtrarRutas" class="btn btn-warning w-100 search-btn">Buscar</button>
        </div>
      </div>
    </div>

    <!-- ruaas disponibles -->
    <div class="container mt-5">
      <div v-if="rutasFiltradas.length > 0" class="row">
        <div v-for="ruta in rutasFiltradas" :key="ruta.id" class="col-md-4">
          <div class="card ruta-card">
            <img :src="obtenerRutaImagen(ruta.foto)" class="card-img-top" alt="Ruta" @error="imagenNoDisponible">
            <div class="card-body text-center">
              <h5 class="card-title">{{ ruta.titulo }}</h5>
              <p class="card-text"><strong>📍 Localidad:</strong> {{ ruta.localidad }}</p>
              <p class="card-text"><strong>📅 Fecha:</strong> {{ ruta.fecha }}</p>
              <p class="card-text"><strong>⏰ Hora:</strong> {{ ruta.hora }}</p>
              <router-link :to="'/ruta/' + ruta.id" class="btn btn-primary w-100 rounded-pill">Ver Detalles</router-link>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="alert alert-warning text-center mt-4">
        No hay rutas disponibles.
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const rutas = ref([]);
const rutasFiltradas = ref([]);
const filtroLocalidad = ref('');
const filtroFecha = ref('');
const videoRef = ref(null);

// controles video
const toggleVideo = () => {
  if (videoRef.value.paused) {
    videoRef.value.play();
  } else {
    videoRef.value.pause();
  }
};

// Cargar rutas desde la API
const cargarRutas = async () => {
  try {
    const response = await fetch('http://localhost/freetours/api.php/rutas');
    const data = await response.json();
    rutas.value = data;
    rutasFiltradas.value = data;
  } catch (error) {
    console.error('Error al cargar rutas:', error);
  }
};

// Filtrar rutas localidad  fecha
const filtrarRutas = () => {
  rutasFiltradas.value = rutas.value.filter(ruta => {
    const coincideLocalidad = filtroLocalidad.value
      ? ruta.localidad.toLowerCase().includes(filtroLocalidad.value.toLowerCase())
      : true;
    const coincideFecha = filtroFecha.value ? ruta.fecha === filtroFecha.value : true;
    return coincideLocalidad && coincideFecha;
  });
};

// imagen de la ruta
const obtenerRutaImagen = (nombreImagen) => {
  if (!nombreImagen) return "/default-image.jpg";
  return `http://localhost/freetours/imagenes/${nombreImagen}`;
};



onMounted(() => {
  cargarRutas();
});
</script>

<style scoped>
/*  video */
.video-section {
  position: relative;
  width: 100%;
  height: 60vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: black;
  overflow: hidden;
  cursor: pointer;
}

.video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.overlay {
  position: absolute;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
}

/*  buscador */
.jumbotron {
  background: linear-gradient(135deg, #004aad, #007bff);
  border-radius: 10px;
  color: white;
}

.search-input {
  border-radius: 50px;
  padding: 12px;
  border: 2px solid #ffc107;
  font-size: 1rem;
}

.search-btn {
  border-radius: 50px;
  font-size: 1.1rem;
  font-weight: bold;
  transition: all 0.3s;
}

.search-btn:hover {
  background-color: #ffae00;
  transform: scale(1.05);
}

/*  tarjetas rutas */
.ruta-card img {
  width: 100%;
  height: 250px; 
  object-fit: cover;
}


.ruta-card:hover {
  transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.card-body {
  padding: 20px;
}
</style>
