<template>
  <div class="container mt-4">
    <h2 class="text-center mb-4 text-primary">📌 Mis Reservas</h2>

    <div v-if="reservas.length > 0" class="row">
      <div v-for="reserva in reservas" :key="reserva.id" class="col-md-6">
        <div class="card reserva-card">
          <img :src="obtenerRutaImagen(reserva.ruta_foto)" class="card-img-top" alt="Ruta">
          <div class="card-body text-center">
            <h5 class="card-title text-dark"><strong>🌍 Ruta:</strong> {{ reserva.ruta_titulo || 'No disponible' }}</h5>
            <p><strong>📅 Fecha:</strong> {{ reserva.ruta_fecha }}</p>
            <p><strong>⏰ Hora:</strong> {{ reserva.ruta_hora }}</p>
            <p><strong>👥 Personas:</strong> {{ reserva.num_personas }}</p>
            <button @click="cancelarReserva(reserva.reserva_id)" class="btn btn-danger w-100 rounded-pill">
              ❌ Cancelar Reserva
            </button>
          </div>
        </div>
      </div>
    </div>

    <div v-else class="alert alert-warning text-center">
      No tienes reservas activas.
    </div>
  </div>
</template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  
  const usuario = ref(JSON.parse(localStorage.getItem('usuario')) || null);
  const reservas = ref([]);
  
  const cargarReservas = async () => {
  if (!usuario.value) {
    console.error("Usuario no autenticado.");
    return;
  }

  try {
    const response = await fetch(`http://localhost/freetours/api.php/reservas?usuario_id=${usuario.value.id}`);
    const data = await response.json();
    console.log("Reservas obtenidas desde la API:", data);

    reservas.value = data;
  } catch (error) {
    console.error("Error al obtener reservas:", error);
  }
};


  
 //CANCELAR RESREVAS
 const cancelarReserva = async (reservaId) => {
  if (!confirm("¿Estás seguro de que deseas cancelar esta reserva?")) return;

  try {
    const response = await fetch(`http://localhost/freetours/api.php/reservas?id=${reservaId}`, {
      method: 'DELETE'
    });

    const data = await response.json();
    if (data.status === 'success') {
      alert("Reserva cancelada correctamente.");
      reservas.value = reservas.value.filter(reserva => reserva.reserva_id !== reservaId);
    } else {
      alert("No se pudo cancelar la reserva.");
    }
  } catch (error) {
    console.error("Error al cancelar reserva:", error);
  }
};
  
  //  url imagen
  const obtenerRutaImagen = (nombreImagen) => {
    return `http://localhost/freetours/imagenes/${nombreImagen}`;
  };
  
  onMounted(() => {
    cargarReservas();
  });

</script>

<style scoped>
.reserva-card {
  border-radius: 15px;
  transition: transform 0.3s, box-shadow 0.3s;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.reserva-card:hover {
  transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}
</style>