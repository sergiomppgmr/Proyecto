<template>
  <div class="container mt-4">
    <h2 class="text-center mb-4">🗺️ Gestión de Rutas</h2>

    <!--btn agregar ruta -->
    <button class="btn btn-success mb-3 w-100" @click="mostrarFormulario = !mostrarFormulario">
      <span v-if="mostrarFormulario">⬆️ Cerrar Formulario</span>
      <span v-else>+ Añadir Nueva Ruta</span>
    </button>

    <!-- formulario agregar rutas -->
    <div v-if="mostrarFormulario" class="card p-4 shadow-sm bg-light">
      <h5 class="text-center">✏️ Nueva Ruta</h5>
      <div class="row">
        <div class="col-md-6">
          <label class="form-label">Título:</label>
          <input v-model="ruta.titulo" type="text" class="form-control mb-2" required>

          <label class="form-label">Localidad:</label>
          <input v-model="ruta.localidad" type="text" class="form-control mb-2" required>

          <label class="form-label">Descripción:</label>
          <textarea v-model="ruta.descripcion" class="form-control mb-2" required></textarea>

          <label class="form-label">Imagen (Nombre de Archivo):</label>
          <input v-model="ruta.foto" type="text" class="form-control mb-2" placeholder="ej: ciudad.jpg">
        </div>

        <div class="col-md-6">
          <label class="form-label">Fecha:</label>
          <input v-model="ruta.fecha" type="date" class="form-control mb-2" required>

          <label class="form-label">Hora:</label>
          <input v-model="ruta.hora" type="time" class="form-control mb-2" required>

          <label class="form-label">Latitud:</label>
          <input v-model="ruta.latitud" type="text" class="form-control mb-2" required>

          <label class="form-label">Longitud:</label>
          <input v-model="ruta.longitud" type="text" class="form-control mb-2" required>
        </div>
      </div>

      <button @click="guardarRuta" class="btn btn-primary w-100 mt-3">💾 Guardar Ruta</button>
    </div>

    <!-- lista rutas existentes -->
    <div v-if="rutas.length > 0" class="table-responsive mt-4">
      <table class="table table-hover">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Localidad</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="ruta in rutas" :key="ruta.id">
            <td>{{ ruta.id }}</td>
            <td>{{ ruta.titulo }}</td>
            <td>{{ ruta.localidad }}</td>
            <td>{{ ruta.fecha }}</td>
            <td>{{ ruta.hora }}</td>
            <td>
              <button @click="eliminarRuta(ruta.id)" class="btn btn-outline-danger btn-sm">
                ❌ Eliminar
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-else class="alert alert-warning text-center mt-4">
      📌 No hay rutas registradas actualmente.
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const rutas = ref([]);
const ruta = ref({ titulo: '', localidad: '', descripcion: '', fecha: '', hora: '', foto: '', latitud: '', longitud: '' });
const mostrarFormulario = ref(false);

//  Cargar rutas desde la API
const cargarRutas = async () => {
  try {
    const response = await fetch('http://localhost/freetours/api.php/rutas');
    const data = await response.json();
    rutas.value = data;
    console.log("✅ Rutas cargadas:", rutas.value);
  } catch (error) {
    console.error("❌ Error al obtener rutas:", error);
  }
};

//  Guardar una nueva ruta
const guardarRuta = async () => {
  try {
    const response = await fetch('http://localhost/freetours/api.php/rutas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ruta.value)
    });

    const data = await response.json();
    if (data.status === 'success') {
      alert("✅ Ruta creada correctamente");
      cargarRutas();
      mostrarFormulario.value = false;
    } else {
      alert("❌ Error al guardar la ruta.");
    }
  } catch (error) {
    console.error("❌ Error al guardar ruta:", error);
  }
};

//  Eliminar una ruta
const eliminarRuta = async (rutaId) => {
  if (!confirm("⚠️ ¿Seguro que deseas eliminar esta ruta?")) return;

  try {
    const response = await fetch(`http://localhost/freetours/api.php/rutas?id=${rutaId}`, {
      method: 'DELETE'
    });

    const data = await response.json();
    if (data.status === 'success') {
      alert("🗑️ Ruta eliminada.");
      rutas.value = rutas.value.filter(r => r.id !== rutaId);
    } else {
      alert("❌ Error al eliminar ruta.");
    }
  } catch (error) {
    console.error("❌ Error al eliminar ruta:", error);
  }
};

//  Cargar rutas al montar la vista
onMounted(() => {
  cargarRutas();
});
</script>

<style scoped>
/* Tarjeta formulario */
.card {
  border-radius: 10px;
  background: #f8f9fa;
}

/* btn añadir ruta */
.btn-success {
  font-weight: bold;
  transition: background 0.3s;
}

.btn-success:hover {
  background: #28a745;
  color: white;
}

/* Tabla */
.table-hover tbody tr:hover {
  background-color: #f1f1f1;
}

/* btn de eliminar */
.btn-outline-danger {
  transition: all 0.3s;
}

.btn-outline-danger:hover {
  background-color: red;
  color: white;
}
</style>
