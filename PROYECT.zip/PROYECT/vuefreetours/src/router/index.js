import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Login from '../views/Login.vue';
import Register from '../views/Register.vue';
import Ruta from '../views/Ruta.vue';
import MisReservas from '../views/MisReservas.vue'; 
import AdminUsuarios from '../views/AdminUsuarios.vue';
import AdminRutas from '../views/AdminRutas.vue';
import MisRutasGuia from '@/views/MisRutasGuia.vue';


const routes = [
    { path: '/', component: Home },
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    { path: '/ruta/:id', component: Ruta, props: true },
    { path: '/mis-reservas', component: MisReservas }, 
    { path: '/admin/usuarios', component: AdminUsuarios, meta: { requiresAuth: true, role: 'admin' } },
    { path: '/admin/rutas', component: AdminRutas, meta: { requiresAuth: true, role: 'admin' } },
    { path: '/guia/rutas', component: () => import('@/views/MisRutasGuia.vue'), meta: { requiresAuth: true, role: 'guia' } },

    {
      path: "/mis-rutas",
      name: "MisRutas",
      component: () => import("@/views/MisRutas.vue"),
      meta: { requiresAuth: true }
    }
    
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

export default router;
